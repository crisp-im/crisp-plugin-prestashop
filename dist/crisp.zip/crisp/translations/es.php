<?php

global $_MODULE;
$_MODULE['<{crisp}prestashop>crisp_09abd3df9e1c00434dd0122c327ba47d'] = 'crisp';
$_MODULE['<{crisp}prestashop>crisp_6110270ed0eef1450e3044de6ecca40a'] = 'Crisp';
$_MODULE['<{crisp}prestashop>crisp_40e654a13abd3fa691f35b9ca4e30772'] = 'Mejore la atención al cliente con Crisp: en cada conversación, obtendrá los datos de los pedidos del cliente sincronizados desde Prestashop.';
$_MODULE['<{crisp}prestashop>configure_633291b401c53c45191f954829ea6879'] = 'Bienvenido a tu panel de control de Crisp';
$_MODULE['<{crisp}prestashop>configure_179a4d2c8965ab67fcb1a3b308285934'] = 'Añade Crisp a tu Prestashop';
$_MODULE['<{crisp}prestashop>configure_4d18e141605887c9bc22d74be0065a3c'] = 'Ahora puedes usar Crisp desde tu página de inicio';
$_MODULE['<{crisp}prestashop>configure_04a84f729cdaa3cd052f3a01152b964d'] = 'Por favor asocie su cuenta Prestashop con este módulo antes';
$_MODULE['<{crisp}prestashop>configure_556b4516573414659b4c854d00278147'] = 'Abrir bandeja de entrada nítida';
$_MODULE['<{crisp}prestashop>configure_9b28f7b5ef440499a113dff8c1c287fb'] = 'Ir a mi configuración de Crisp';
$_MODULE['<{crisp}prestashop>configure_516dd57448e10a9d81c43cfd5ce9013d'] = 'Conectar Crisp a mi Prestashop';
$_MODULE['<{crisp}prestashop>configure_25b3bc6f6c8001d0bb2b8500bd8eb192'] = 'Al hacer clic en el siguiente enlace, agregaremos automáticamente el chatbox de Crisp a tu Prestashop';
$_MODULE['<{crisp}prestashop>configure_88c18639485b1d7b0d917c66e75c1cd3'] = 'Instalar Crisp en mi Prestashop';
$_MODULE['<{crisp}prestashop>configure_ce646028e5e9dc806b9a49353bb79833'] = 'Por favor, asocie su cuenta Prestashop con este módulo antes de continuar.';
$_MODULE['<{crisp}prestashop>configure_7ccff4900a2ae401f46e5242e50075dc'] = 'Los datos de Prestashop se sincronizan ahora con Crisp a través de Cloudsync. Habilite el servicio web de su tienda para poder ver los datos de sus clientes desde Crisp';
$_MODULE['<{crisp}prestashop>configure_5f371f22c35f261aac1400fbc700561c'] = 'Incluir Crisp Chatbox en el escaparate.';
$_MODULE['<{crisp}prestashop>configure_3a220dc592e9c4c3ae20df185f94fe84'] = 'Active esta opción para mostrar el Chatbox en su tienda.';
$_MODULE['<{crisp}prestashop>configure_5ed0265ffe0a132444add7166d37c110'] = 'Utilizar el servicio web de la tienda.';
$_MODULE['<{crisp}prestashop>configure_bca51dc2d230f25861bbafb8d3d7986e'] = 'Active esta opción para permitir que Crisp utilice el servicio web de la tienda para buscar clientes y los detalles de sus pedidos.';
$_MODULE['<{crisp}prestashop>configure_d68af78b816b08e711e70d9a18440f25'] = 'Configure Crisp para su tienda Prestashop';
$_MODULE['<{crisp}prestashop>configure_a301fb6c9931e5b86a9b36a31b9c9e6d'] = 'Opciones adicionales';
$_MODULE['<{crisp}prestashop>configure_402a8d299a4018f8fd24b7e1b87ea357'] = 'Crisp se ha vinculado correctamente con sus datos de Prestashop.';
$_MODULE['<{crisp}prestashop>configure_ee26bf8545866b59f242ba687deb4594'] = 'Dispone de una clave de webservice de Crisp pero no está habilitada. Por favor, vincule el webservice y habilítelo en Parámetros Avanzados > Webservice.';
$_MODULE['<{crisp}prestashop>configure_07ebbd9e476c9d7ba0cbea431ce4e9cc'] = 'Vincular Webservice a Crisp';
$_MODULE['<{crisp}prestashop>configure_c7139317ffae2a55fc4620049149d543'] = 'Vuelva a vincular Webservice a Crisp';
