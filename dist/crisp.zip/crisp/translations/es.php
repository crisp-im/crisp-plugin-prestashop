<?php

global $_MODULE;
$_MODULE['<{crisp}prestashop>crisp_09abd3df9e1c00434dd0122c327ba47d'] = 'crisp';
$_MODULE['<{crisp}prestashop>crisp_6110270ed0eef1450e3044de6ecca40a'] = 'Crisp';
$_MODULE['<{crisp}prestashop>crisp_40e654a13abd3fa691f35b9ca4e30772'] = 'Mejore la atención al cliente con Crisp: en cada conversación, obtendrá los datos de los pedidos del cliente sincronizados desde Prestashop.';
$_MODULE['<{crisp}prestashop>configure_633291b401c53c45191f954829ea6879'] = 'Bienvenido a tu panel de control de Crisp';
$_MODULE['<{crisp}prestashop>configure_179a4d2c8965ab67fcb1a3b308285934'] = 'Añade Crisp a tu Prestashop';
$_MODULE['<{crisp}prestashop>configure_4d18e141605887c9bc22d74be0065a3c'] = 'Ahora puedes usar Crisp desde tu página de inicio';
$_MODULE['<{crisp}prestashop>configure_04a84f729cdaa3cd052f3a01152b964d'] = 'Por favor asocie su cuenta Prestashop con este módulo antes';
$_MODULE['<{crisp}prestashop>configure_556b4516573414659b4c854d00278147'] = 'Abrir bandeja de entrada nítida';
$_MODULE['<{crisp}prestashop>configure_9b28f7b5ef440499a113dff8c1c287fb'] = 'Ir a mi configuración de Crisp';
$_MODULE['<{crisp}prestashop>configure_516dd57448e10a9d81c43cfd5ce9013d'] = 'Conectar Crisp a mi Prestashop';
$_MODULE['<{crisp}prestashop>configure_25b3bc6f6c8001d0bb2b8500bd8eb192'] = 'Al hacer clic en el siguiente enlace, agregaremos automáticamente el chatbox de Crisp a tu Prestashop';
$_MODULE['<{crisp}prestashop>configure_88c18639485b1d7b0d917c66e75c1cd3'] = 'Instalar Crisp en mi Prestashop';
