<?php

global $_MODULE;
$_MODULE['<{crisp}prestashop>crisp_09abd3df9e1c00434dd0122c327ba47d'] = 'crisp';
$_MODULE['<{crisp}prestashop>crisp_6110270ed0eef1450e3044de6ecca40a'] = 'Crisp - Live chat & AI Chatbot';
$_MODULE['<{crisp}prestashop>crisp_40e654a13abd3fa691f35b9ca4e30772'] = 'Améliorez le support client avec Crisp : pour chaque conversation, vous obtenez les données des commandes du client synchronisées avec Prestashop.';
$_MODULE['<{crisp}prestashop>configure_633291b401c53c45191f954829ea6879'] = 'Bienvenue sur votre panneau de configuration Crisp';
$_MODULE['<{crisp}prestashop>configure_179a4d2c8965ab67fcb1a3b308285934'] = 'Ajouter Crisp à votre Prestashop';
$_MODULE['<{crisp}prestashop>configure_4d18e141605887c9bc22d74be0065a3c'] = 'Vous pouvez désormais utiliser Crisp depuis votre page d\'accueil';
$_MODULE['<{crisp}prestashop>configure_04a84f729cdaa3cd052f3a01152b964d'] = 'Merci d\'associer votre compte prestashop à ce module avant';
$_MODULE['<{crisp}prestashop>configure_556b4516573414659b4c854d00278147'] = 'Ouvrir la boîte de réception Crisp';
$_MODULE['<{crisp}prestashop>configure_9b28f7b5ef440499a113dff8c1c287fb'] = 'Accédez à mes paramètres Crisp';
$_MODULE['<{crisp}prestashop>configure_516dd57448e10a9d81c43cfd5ce9013d'] = 'Relier Crisp à mon Prestashop';
$_MODULE['<{crisp}prestashop>configure_25b3bc6f6c8001d0bb2b8500bd8eb192'] = 'En cliquant sur le lien suivant, nous ajouterons automatiquement la chatbox Crisp sur votre Prestashop';
$_MODULE['<{crisp}prestashop>configure_88c18639485b1d7b0d917c66e75c1cd3'] = 'Installer Crisp sur mon Prestashop';
$_MODULE['<{crisp}prestashop>configure_ce646028e5e9dc806b9a49353bb79833'] = 'Veuillez associer votre compte Prestashop à ce module avant de continuer.';
$_MODULE['<{crisp}prestashop>configure_7ccff4900a2ae401f46e5242e50075dc'] = 'Les données de Prestashop sont maintenant synchronisées avec Crisp à travers Cloudsync. Activez la connexion avec votre boutique afin de voir les données de vos clients depuis Crisp.';
$_MODULE['<{crisp}prestashop>configure_5f371f22c35f261aac1400fbc700561c'] = 'Inclure la Chatbox Crisp sur votre boutique en ligne.';
$_MODULE['<{crisp}prestashop>configure_3a220dc592e9c4c3ae20df185f94fe84'] = 'Activez cette option pour afficher la Chatbox sur votre boutique.';
$_MODULE['<{crisp}prestashop>configure_5ed0265ffe0a132444add7166d37c110'] = 'Utiliser les API de la boutique en ligne.';
$_MODULE['<{crisp}prestashop>configure_bca51dc2d230f25861bbafb8d3d7986e'] = 'Activez cette option pour permettre à Crisp d\'utiliser les données de votre boutique en ligne pour trouver les clients et les détails de leurs commandes.';
$_MODULE['<{crisp}prestashop>configure_d68af78b816b08e711e70d9a18440f25'] = 'Configurer Crisp pour votre boutique Prestashop';
$_MODULE['<{crisp}prestashop>configure_a301fb6c9931e5b86a9b36a31b9c9e6d'] = 'Options supplémentaires';
$_MODULE['<{crisp}prestashop>configure_402a8d299a4018f8fd24b7e1b87ea357'] = 'Crisp a été relié avec succès à vos données Prestashop.';
$_MODULE['<{crisp}prestashop>configure_ee26bf8545866b59f242ba687deb4594'] = 'Vous avez une clé de webservice Crisp mais elle n\'est pas activée. Veuillez lier le webservice et l\'activer dans Paramètres avancés > Webservice.';
$_MODULE['<{crisp}prestashop>configure_07ebbd9e476c9d7ba0cbea431ce4e9cc'] = 'Lier l\'API à Crisp';
$_MODULE['<{crisp}prestashop>configure_c7139317ffae2a55fc4620049149d543'] = 'Relier l\'API à Crisp';
