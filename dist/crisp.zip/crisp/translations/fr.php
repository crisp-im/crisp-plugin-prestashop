<?php

global $_MODULE;
$_MODULE['<{crisp}prestashop>crisp_09abd3df9e1c00434dd0122c327ba47d'] = 'crisp';
$_MODULE['<{crisp}prestashop>crisp_6110270ed0eef1450e3044de6ecca40a'] = 'Crisp';
$_MODULE['<{crisp}prestashop>crisp_40e654a13abd3fa691f35b9ca4e30772'] = 'Améliorez le support client avec Crisp : pour chaque conversation, vous obtenez les données des commandes du client synchronisées avec Prestashop.';
$_MODULE['<{crisp}prestashop>configure_633291b401c53c45191f954829ea6879'] = 'Bienvenue sur votre panneau de configuration Crisp';
$_MODULE['<{crisp}prestashop>configure_179a4d2c8965ab67fcb1a3b308285934'] = 'Ajouter Crisp à votre Prestashop';
$_MODULE['<{crisp}prestashop>configure_4d18e141605887c9bc22d74be0065a3c'] = 'Vous pouvez désormais utiliser Crisp depuis votre page d\'accueil';
$_MODULE['<{crisp}prestashop>configure_04a84f729cdaa3cd052f3a01152b964d'] = 'Merci d\'associer votre compte prestashop à ce module avant';
$_MODULE['<{crisp}prestashop>configure_556b4516573414659b4c854d00278147'] = 'Ouvrir la boîte de réception Crisp';
$_MODULE['<{crisp}prestashop>configure_9b28f7b5ef440499a113dff8c1c287fb'] = 'Accédez à mes paramètres Crisp';
$_MODULE['<{crisp}prestashop>configure_516dd57448e10a9d81c43cfd5ce9013d'] = 'Relier Crisp à mon Prestashop';
$_MODULE['<{crisp}prestashop>configure_25b3bc6f6c8001d0bb2b8500bd8eb192'] = 'En cliquant sur le lien suivant, nous ajouterons automatiquement la chatbox Crisp sur votre Prestashop';
$_MODULE['<{crisp}prestashop>configure_88c18639485b1d7b0d917c66e75c1cd3'] = 'Installer Crisp sur mon Prestashop';
